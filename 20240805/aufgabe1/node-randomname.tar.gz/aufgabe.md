1. Eine coole website erstellen
2. Server mit express launchen
3. beim http//:localhost:3000/website (GET request) soll die Webseite geladen werden!!
4. demo (random names)